# webprojekt

## Feedback Sign In, Datenschutz & Impressum
Sieht super aus soweit! Vielen Dank auf jeden Fall fürs Ransetzen :)
Was mir jedoch aufgefallen ist, dass man sobald man auf "Datenschutz" oder "Impressum" klickt keine Möglichkeit mehr hat zurück zur Registrierung oder Log-In Seite zu kommen. Da müsste dann gegebenenfalls ein "Zurück" Bottun oder ähnliches eingebaut werden.
Ansonsten kann ich die Funktionsweise mit der DB ja leider nicht checken, weil es ja über deine läuft, Linus, aber das scheint mir erst einmal so richtig.

Kann ich mich schon registrieren, also funktioniert das schon? Da müssten wir dann mal schauen wie das abläuft auch von der Sicherheit her, weil wir da ja auch drauf achten sollen.

## RE: Feedback, Sign In, Datenschutz & Impressum
Ich wollte eventuell eh noch eine Navigationsleiste einfügen, mal schauen ob ich das mache, sonst kommt natürlich noch ein Button, soweit war ich nur noch nicht.

Das mit der Datenbank und registrieren funktioniert noch NICHT, habe mich erstmal auf die html-Seite konzentriert, daran mach ich mich jetzt aber bald. Ich glaube Sicherheit ist im unglaublich wichtig, da muss ich mich nochmal bisschen schlau machen. 
