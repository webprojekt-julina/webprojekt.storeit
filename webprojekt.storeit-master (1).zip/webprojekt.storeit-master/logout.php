<?php
session_start();
session_destroy();
include("sign_in.html")
?>